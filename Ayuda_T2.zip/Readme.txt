En static_and_follow_camera se puede observar cómo jugar con las cámaras.

En illumination_example se agregan luces.